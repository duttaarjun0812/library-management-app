import React from 'react'
const [favorites, setFavorites] = useState([]);
function Favourite() {
  return (
    <div>Favourite</div>
  )
}

export default Favourite